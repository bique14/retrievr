/**
 * Receives a batch of one or more files sent by `sendFiles` over an
 * `RTCDataChannel`, streaming each chunk straight to disk via the File
 * System Access API so the receiver never buffers a whole file in memory
 * either.
 *
 * Chrome only allows `showDirectoryPicker()` to be called while handling a
 * user gesture, so the picker can't be shown automatically the instant
 * `batch-info` arrives. Instead, the offer is surfaced via `onOffer` and
 * the caller must invoke `accept()` from a click handler; only then is the
 * picker shown and a `batch-accept` sent back so the sender starts
 * streaming files. Every file in the batch is then written under that one
 * chosen directory, recreating subfolders from each file's `relativePath`.
 *
 * Writes are serialized through a promise queue: DataChannel `message`
 * events can fire faster than disk writes complete, and
 * `FileSystemWritableFileStream.write()` calls must not overlap or chunks
 * can land out of order on disk.
 */
import {
  decodeChunkFrame,
  parseControlMessage,
  splitRelativePath,
  type BatchAcceptMessage,
  type BatchDeclineMessage,
} from "./transfer-protocol";
import { logEvent } from "./diagnostics";

/**
 * Devices without `showDirectoryPicker` (iPhone/iPad and Android browsers)
 * must buffer each incoming file entirely in memory before triggering a
 * download, so batches beyond this size are refused up front rather than
 * crashing the tab mid-transfer.
 */
const MAX_FALLBACK_BATCH_BYTES = 2 * 1024 * 1024 * 1024;

export interface FileReceiveProgress {
  bytesReceived: number;
  totalBytes: number;
}

export interface BatchOfferInfo {
  fileCount: number;
  totalBytes: number;
}

export interface ReceivingFileInfo {
  name: string;
  relativePath: string;
  size: number;
  fileIndex: number;
  fileCount: number;
}

export interface FileReceiverCallbacks {
  /** Called once a batch offer arrives; waits here until `accept()` or `decline()` is called. */
  onOffer(info: BatchOfferInfo): void;
  /** Called once a given file within the (already-accepted) batch starts writing. */
  onFileStart(info: ReceivingFileInfo): void;
  onProgress(progress: FileReceiveProgress): void;
  onFileComplete(info: ReceivingFileInfo): void;
  onBatchComplete(): void;
  onError(message: string): void;
  /** Sender paused or resumed streaming mid-transfer. */
  onPauseChange?(paused: boolean): void;
}

export class FileReceiver {
  private readonly channel: RTCDataChannel;
  private readonly callbacks: FileReceiverCallbacks;
  private pendingOffer: BatchOfferInfo | null = null;
  private directoryHandle: FileSystemDirectoryHandle | null = null;
  private useDownloadFallback = false;
  private fileCount = 0;
  private currentFile: ReceivingFileInfo | null = null;
  private writable: FileSystemWritableFileStream | null = null;
  private downloadChunks: ArrayBuffer[] = [];
  private downloadMimeType = "application/octet-stream";
  private bytesReceived = 0;
  private queue: Promise<void> = Promise.resolve();

  constructor(channel: RTCDataChannel, callbacks: FileReceiverCallbacks) {
    this.channel = channel;
    this.callbacks = callbacks;
    channel.binaryType = "arraybuffer";
    channel.addEventListener("message", this.handleMessageEvent);
  }

  /**
   * Shows the destination-folder picker and, once chosen, tells the sender
   * to start streaming. Must be called synchronously from a user gesture
   * (e.g. a button's onClick), or Chrome rejects `showDirectoryPicker()`.
   */
  async accept(): Promise<void> {
    const offer = this.pendingOffer;
    if (!offer) return;

    logEvent("receive", "accept-clicked");
    if (typeof window.showDirectoryPicker !== "function") {
      if (offer.totalBytes > MAX_FALLBACK_BATCH_BYTES) {
        logEvent("receive", "fallback-too-large", {
          totalBytes: offer.totalBytes,
        });
        this.pendingOffer = null;
        this.channel.send(
          JSON.stringify({
            type: "batch-decline",
          } satisfies BatchDeclineMessage),
        );
        this.callbacks.onError(
          "This device can only receive up to 2 GB per transfer. Try sending smaller batches, or receive on a desktop browser.",
        );
        return;
      }
      this.pendingOffer = null;
      this.useDownloadFallback = true;
      this.fileCount = offer.fileCount;
      this.channel.send(
        JSON.stringify({ type: "batch-accept" } satisfies BatchAcceptMessage),
      );
      logEvent("receive", "batch-accept-sent", {
        mode: "download-fallback",
      });
      return;
    }

    let handle: FileSystemDirectoryHandle;
    try {
      handle = await window.showDirectoryPicker({ mode: "readwrite" });
    } catch {
      // User dismissed the picker; treat it the same as an explicit decline.
      logEvent("receive", "directory-picker-dismissed");
      this.decline();
      return;
    }
    logEvent("receive", "directory-picker-resolved");

    this.pendingOffer = null;
    this.useDownloadFallback = false;
    this.directoryHandle = handle;
    this.fileCount = offer.fileCount;
    this.channel.send(
      JSON.stringify({ type: "batch-accept" } satisfies BatchAcceptMessage),
    );
    logEvent("receive", "batch-accept-sent");
  }

  /** Rejects the pending batch offer and tells the sender to stop. */
  decline(): void {
    if (!this.pendingOffer) return;
    this.pendingOffer = null;
    this.channel.send(
      JSON.stringify({ type: "batch-decline" } satisfies BatchDeclineMessage),
    );
  }

  /** Detaches from the channel and releases any in-progress file/batch state. */
  dispose(): void {
    this.channel.removeEventListener("message", this.handleMessageEvent);
    // Chain onto the write queue so an in-flight write finishes before the
    // writable is closed; otherwise a mid-receive unmount (e.g. the data
    // channel being replaced) leaks an open FileSystemWritableFileStream.
    this.queue = this.queue.then(() => this.resetBatchState()).catch(() => {});
  }

  private readonly handleMessageEvent = (
    event: MessageEvent<string | ArrayBuffer>,
  ): void => {
    // Chain onto the queue so writes are always processed strictly in
    // arrival order, even if disk I/O is slower than message delivery.
    this.queue = this.queue
      .then(() => this.handleMessage(event.data))
      .catch((error: unknown) => {
        this.callbacks.onError(
          error instanceof Error ? error.message : "Unknown transfer error.",
        );
      });
  };

  private async handleMessage(data: string | ArrayBuffer): Promise<void> {
    if (typeof data === "string") {
      await this.handleControlMessage(data);
      return;
    }
    await this.handleChunk(data);
  }

  /** Resolves (creating as needed) the nested file handle for a validated relative path. */
  private async resolveFileHandle(
    root: FileSystemDirectoryHandle,
    segments: string[],
  ): Promise<FileSystemFileHandle> {
    let dir = root;
    for (const segment of segments.slice(0, -1)) {
      dir = await dir.getDirectoryHandle(segment, { create: true });
    }
    const fileName = segments[segments.length - 1];
    if (fileName === undefined) throw new Error("Empty file path.");
    return dir.getFileHandle(fileName, { create: true });
  }

  /** Closes any open writable and clears all in-progress batch/file state. */
  private async resetBatchState(): Promise<void> {
    await this.writable?.close().catch(() => {
      // The writable may already be closed/aborted (e.g. sender cancelled
      // mid-write); nothing more to do here.
    });
    this.writable = null;
    this.directoryHandle = null;
    this.useDownloadFallback = false;
    this.downloadChunks = [];
    this.downloadMimeType = "application/octet-stream";
    this.currentFile = null;
    this.fileCount = 0;
    this.bytesReceived = 0;
  }

  private downloadCurrentFile(): void {
    if (!this.currentFile) return;
    const blob = new Blob(this.downloadChunks, { type: this.downloadMimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = this.currentFile.name;
    anchor.rel = "noopener";
    anchor.style.display = "none";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }

  private async handleControlMessage(raw: string): Promise<void> {
    const message = parseControlMessage(raw);
    if (!message) return; // ignore malformed frames rather than crashing the session

    switch (message.type) {
      case "batch-info": {
        logEvent("receive", "batch-info-received", {
          fileCount: message.fileCount,
          totalBytes: message.totalBytes,
        });
        if (this.pendingOffer || this.directoryHandle) {
          this.callbacks.onError(
            "Received a new transfer while another was in progress.",
          );
          return;
        }
        this.pendingOffer = {
          fileCount: message.fileCount,
          totalBytes: message.totalBytes,
        };
        this.callbacks.onOffer(this.pendingOffer);
        return;
      }

      case "file-info": {
        if (!this.directoryHandle && !this.useDownloadFallback) {
          this.callbacks.onError(
            "Received file data before the transfer was accepted.",
          );
          return;
        }
        const segments = splitRelativePath(message.relativePath);
        if (!segments) {
          this.callbacks.onError(
            `Refusing unsafe file path: "${message.relativePath}".`,
          );
          return;
        }

        const fileIndex = this.currentFile ? this.currentFile.fileIndex + 1 : 0;
        this.currentFile = {
          name: message.name,
          relativePath: message.relativePath,
          size: message.size,
          fileIndex,
          fileCount: this.fileCount,
        };
        this.bytesReceived = 0;

        if (this.useDownloadFallback) {
          if (segments.length !== 1) {
            this.callbacks.onError(
              "This browser can only receive plain files right now. Folder transfers are disabled.",
            );
            return;
          }
          this.downloadChunks = [];
          this.downloadMimeType =
            message.mimeType || "application/octet-stream";
          this.callbacks.onFileStart(this.currentFile);
          return;
        }

        const directoryHandle = this.directoryHandle;
        if (!directoryHandle) {
          this.callbacks.onError(
            "Received file data before the transfer was accepted.",
          );
          return;
        }

        const handle = await this.resolveFileHandle(directoryHandle, segments);
        this.writable = await handle.createWritable();
        this.callbacks.onFileStart(this.currentFile);
        return;
      }

      case "transfer-complete": {
        const completedFile = this.currentFile;
        if (completedFile && this.bytesReceived !== completedFile.size) {
          // The channel is ordered+reliable, so a mismatch means sender-side
          // truncation or protocol corruption — never silently keep a
          // partial file on disk.
          logEvent("receive", "size-mismatch", {
            relativePath: completedFile.relativePath,
            expected: completedFile.size,
            received: this.bytesReceived,
          });
          await this.resetBatchState();
          this.callbacks.onError(
            `"${completedFile.relativePath}" arrived incomplete (${this.bytesReceived} of ${completedFile.size} bytes). Ask the sender to try again.`,
          );
          return;
        }
        if (this.useDownloadFallback) {
          this.downloadCurrentFile();
          this.downloadChunks = [];
        }
        await this.writable?.close();
        this.writable = null;
        if (completedFile) this.callbacks.onFileComplete(completedFile);
        return;
      }

      case "batch-complete": {
        await this.resetBatchState();
        this.callbacks.onPauseChange?.(false);
        this.callbacks.onBatchComplete();
        return;
      }

      case "transfer-error":
        await this.resetBatchState();
        this.callbacks.onPauseChange?.(false);
        this.callbacks.onError(message.message);
        return;

      case "transfer-paused":
        this.callbacks.onPauseChange?.(true);
        return;

      case "transfer-resumed":
        this.callbacks.onPauseChange?.(false);
        return;

      // Accept/decline are sent by receivers, not to them; a receiver only
      // ever sees these echoed back if it also happens to be sending a
      // batch on the same channel, in which case sendFiles' own listener
      // (not this one) is responsible for consuming them.
      case "batch-accept":
      case "batch-decline":
        return;
    }
  }

  private async handleChunk(frame: ArrayBuffer): Promise<void> {
    const { payload } = decodeChunkFrame(frame);
    if (this.useDownloadFallback) {
      this.downloadChunks.push(payload.slice().buffer);
      this.bytesReceived += payload.length;
      this.callbacks.onProgress({
        bytesReceived: this.bytesReceived,
        totalBytes: this.currentFile?.size ?? 0,
      });
      return;
    }

    if (!this.writable) return; // stray chunk before file-info or after completion

    await this.writable.write(payload);
    this.bytesReceived += payload.length;
    this.callbacks.onProgress({
      bytesReceived: this.bytesReceived,
      totalBytes: this.currentFile?.size ?? 0,
    });
  }
}
